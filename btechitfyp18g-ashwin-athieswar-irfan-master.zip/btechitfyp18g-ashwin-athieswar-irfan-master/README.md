Since the spectrum bands are becoming crowded these days, Wireless sensor networks suffer from
severe interference. The cognitive radio sensor networks (CRSNs) address the problem by providing
a viable solution by enabling sensor nodes to select and access licensed bands opportunistically.
Nonetheless, to support Cognitive Radio abilities, such as sensing and switching of channels, it is
necessary for the sensor nodes to consume significant amount of energy. So , the energy efficiency factor for Cognitive Radio sensor
networks are implemented in intra-cluster and inter-cluster data transmission, respectively.
